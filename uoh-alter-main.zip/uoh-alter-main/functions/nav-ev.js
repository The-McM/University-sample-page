document.getElementsByClassName('pl')[1].addEventListener('mouseover', () =>{
    document.getElementsByClassName('ab-men')[0].classList.add('dview')
    
})

document.getElementsByClassName('pl')[1].addEventListener('mouseout', () =>{
    document.getElementsByClassName('ab-men')[0].classList.remove('dview')
    

})

document.getElementsByClassName('pl')[2].addEventListener('mouseover', () =>{
    document.getElementsByClassName('ac-men')[0].classList.add('dview')
    

})

document.getElementsByClassName('pl')[2].addEventListener('mouseout', () =>{
    document.getElementsByClassName('ac-men')[0].classList.remove('dview')


})
document.getElementsByClassName('pl')[3].addEventListener('mouseover', () =>{
    document.getElementsByClassName('re-men')[0].classList.add('dview')

})

document.getElementsByClassName('pl')[3].addEventListener('mouseout', () =>{
    document.getElementsByClassName('re-men')[0].classList.remove('dview')

})
document.getElementsByClassName('pl')[4].addEventListener('mouseover', () =>{
    document.getElementsByClassName('ad-men')[0].classList.add('dview')

})

document.getElementsByClassName('pl')[4].addEventListener('mouseout', () =>{
    document.getElementsByClassName('ad-men')[0].classList.remove('dview')

})